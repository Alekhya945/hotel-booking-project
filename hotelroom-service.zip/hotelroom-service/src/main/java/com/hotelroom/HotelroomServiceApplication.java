package com.hotelroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelroomServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelroomServiceApplication.class, args);
	}

}
