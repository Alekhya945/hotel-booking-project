package com.hotelroom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hotelroom.entity.RoomDetails;

@Service
public interface RoomDetailsService {
	
		RoomDetails getRoomDetailsById(int roomId);

		RoomDetails createRoomDetails(RoomDetails roomDetails);
		
		void deleteRoomDetails(int roomId);
		
		List<RoomDetails> getAllRoomDetails();
	 
	 

}
