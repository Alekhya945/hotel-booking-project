package com.hotelroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelroomServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
